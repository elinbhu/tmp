#!usr/bin/python
import os
var=raw_input("Please input an integer:")
for i in range(0,var):
    var=var+i

